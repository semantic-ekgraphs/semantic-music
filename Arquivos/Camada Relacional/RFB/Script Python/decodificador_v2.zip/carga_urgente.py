import os
import shutil
import time
import json
import execute_func_oracle

empresas = 1
socios = 1
cnaes_sec = 1
qualif_socio = 1
natu_jur = 1
motivos_situ = 1
PATH_RFB_ANTIGOS = 'rfb_antigos/'
PATH_DATA = 'data/'
PATH_OUTPUT = 'output/'

date_start = time.strftime("%Y-%m-%d")

if not os.path.isdir(PATH_RFB_ANTIGOS): #Diretório de arquivos não existe
	os.mkdir(PATH_RFB_ANTIGOS)

tem_atualizacao = True
date_RFB = 0
	
with open("register_scrapping.json","r") as register_file:
	register = json.load(register_file)

	if register == None or register["date_last_update"] != "":
		qualif_socio = 0
		natu_jur = 0
		motivos_situ = 0
	
		date_RFB = register["date_last_update"]

if tem_atualizacao:
	date_splitted = date_RFB.split("/")
	data_gravacao = "{0}_{1}_{2}".format(date_splitted[2],date_splitted[1],date_splitted[0])
	path_gravacao = "{0}{1}/".format(PATH_RFB_ANTIGOS,data_gravacao)
	if not os.path.isdir(path_gravacao): #Diretório de arquivos não existe
		os.mkdir(path_gravacao)#para armazenar .zip da rfb apos carga

	#deixar arquivos baixados .zip em .csv
	#fazer a carga dos .csv para o oracle

	message = "Inicio extracao dados RFB "+time.strftime("%Y-%m-%dT%H:%M:%S")
	print(message)
	carga = "python sql_loader_oracle_rfb.py {0} {1} {2} {3} {4} {5}".format(empresas, socios, cnaes_sec, qualif_socio, natu_jur, motivos_situ)
	for file in os.listdir(PATH_DATA):
		message ="\n\n\n--------------------------------------------\nProcessando arquivo: "+file+"\n\n\n"
		print(message)
		file_path = PATH_DATA + file
		gera_csv = 'python "cnpj.py" "{}" csv "output"'.format(file_path)
		file_out_emp = 'empresas.csv'
		file_out_soc = 'socios.csv'
		file_out_cs = 'cnaes_secundarios.csv'
		attempts = 0
		carga_tb_norm = 0
		while attempts < 3: #and not file_out_emp in os.listdir(PATH_OUTPUT) and not file_out_soc in os.listdir(PATH_OUTPUT) and not file_out_cs in os.listdir(PATH_OUTPUT):
			attempts += 1
			gerou_csv = 0 #os.system(gera_csv)
			if gerou_csv == 0:
				attempts = 3
				message = "Inicio sql loader arquivo "+file+" "+time.strftime("%Y-%m-%dT%H:%M:%S")
				print(message)
				carga_tb_norm = os.system(carga)
				if carga_tb_norm == 0:
					message = "Fim sql loader arquivo "+file+" "+time.strftime("%Y-%m-%dT%H:%M:%S")
					print(message)
					if os.stat("carga/empresas.bad")[6] == 0.0 and os.stat("carga/socios.bad")[6] == 0.0 and os.stat("carga/cnaes_secundarios.bad")[6] == 0.0:
						continue
					else:
						print("problema no sqlldr, verificar arquivos .bad na pasta carga. Limpe-os apos correcao do problema!")
						break
				else:
					break
			else: 
				for files in os.listdir(PATH_OUTPUT):
					os.remove(PATH_OUTPUT+files) #remove possivel csv incompleto gerado
		
		if not file_out_emp in os.listdir(PATH_OUTPUT) or not file_out_soc in os.listdir(PATH_OUTPUT) or not file_out_cs in os.listdir(PATH_OUTPUT):
			print("Nao foi possivel extrair os arquivos compactados para csv")
			break
		
		#for files in os.listdir(PATH_OUTPUT):
		#	os.remove(PATH_OUTPUT+files) #remove csv apos a carga

		if carga_tb_norm != 0:
			print("erro no carregamento do sql loader")
			break

	message = "Fim extracao dados RFB "+time.strftime("%Y-%m-%dT%H:%M:%S")
	print(message)
	#move os .zip da rfb para seu dir com data de atualizacao
	for file in os.listdir(PATH_DATA):
		shutil.move(PATH_DATA+file,path_gravacao)

else:
	print("sem atualizacao")
#######fim###
