from dotenv_decodificador import *

path_sqlldr = path_sqlldr
username = username
password = password
dsn = dsn
port = port
encoding_db = encoding_db
banco_dados = banco_dados
arq_ctl_motivos_situacao = arq_ctl_motivos_situacao
path_carga_v2 = path_carga_v2
arq_ctl_extr_empresas = arq_ctl_extr_empresas
arq_ctl_extr_estabelecimento = arq_ctl_extr_estabelecimento
arq_ctl_extr_socio = arq_ctl_extr_socio
arq_ctl_extr_simples = arq_ctl_extr_simples
arq_ctl_extr_pais = arq_ctl_extr_pais
arq_ctl_extr_municipio = arq_ctl_extr_municipio
arq_ctl_extr_cnae = arq_ctl_extr_cnae
arq_ctl_extr_qualificacao_socio = arq_ctl_extr_qualificacao_socio
arq_ctl_extr_natureza_juridica = arq_ctl_extr_natureza_juridica
