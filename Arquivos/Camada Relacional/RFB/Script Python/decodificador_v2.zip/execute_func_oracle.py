import cx_Oracle
#import config_db_oracle as cfg
from config_loader import username, password, dsn, encoding_db
import requests
import re
import os
import shutil
import json
import time  



def retorna_data():
    with open("register_scrapping.json","r") as register_file:
        register = json.load(register_file)
    return (register["date_last_update"])





def cria_tb ():
    data = retorna_data()
    data = data.replace("/", "-")
    sql = ("insert into hist_carga (data_carga,versao_layout) values(:data_carga,:versao) ")
    versao = 'v2'
    data_carga = data
    try:
        # create a connection to the Oracle Database
        #cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_12_2") # for windows platform
        with cx_Oracle.connect(username,
                            password,
                            dsn,  
                            encoding=encoding_db) as connection:
            # create a new cursor
            with connection.cursor() as cursor:
                # call the function
                revenue = cursor.execute(sql,[data_carga,versao])
                connection.commit()
    except cx_Oracle.Error as error:
        print(error)

cria_tb()

# def load_tabelas_normalizadas():
#     load_norm = None
#     try:
#         # create a connection to the Oracle Database
#         cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_12_2") # for windows platform
#         with cx_Oracle.connect(username,
#                             password,
#                             dsn,
#                             encoding=encoding_db) as connection:
#             # create a new cursor
#             with connection.cursor() as cursor:
#                 # call the function
#                 load_norm = cursor.callfunc('carrega_tb_norm',
#                                         int,
#                                         [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
#                 if load_norm == 1:
#                     connection.commit()
#                 else:
#                     connection.rollback()
                
    
    # except cx_Oracle.Error as error:
    #     print(error)
'''
def load_tabelas_normalizadas_1():
    load_norm = None
    try:
        # create a connection to the Oracle Database
        #cx_Oracle.init_oracle_client(lib_dir=r"C:\oraclexe\app\oracle\instantclient_19_11") # for windows platform
        with cx_Oracle.connect(username,
                            password,
                            dsn,  
                            encoding=encoding_db) as connection:
            # create a new cursor
            with connection.cursor() as cursor:
                # call the function
                load_norm = cursor.callfunc('POVOA_RFB_EMPRESA',
                                        int
                                        )
                if load_norm == 13:
                     print("Povoando...")
                     connection.commit()
                     print("Ok!")
                else:
                    print("Erro no povoamento da POVOA_RFB_EMPRESA")
                    connection.rollback()
                
    
    except cx_Oracle.Error as error:
        print(error)



'''